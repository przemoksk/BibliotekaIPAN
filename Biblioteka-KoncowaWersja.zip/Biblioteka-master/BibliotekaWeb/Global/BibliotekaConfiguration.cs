﻿namespace BibliotekaWeb
{
    public class BibliotekaConfiguration
    {
        public string BibliotekaApiUrl { get; set; }
        public string StorageConnectionString { get; set; }
        public string StorageContainerName { get; set; }
    }
}